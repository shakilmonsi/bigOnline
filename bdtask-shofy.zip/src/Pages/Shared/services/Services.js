import React from 'react';

const Services=()=> {
        return (
                <div class="container categories">
    <h1>service</h1>
    </div>
        );
}

export default Services;