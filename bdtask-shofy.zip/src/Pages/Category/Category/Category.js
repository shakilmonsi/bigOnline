import React from 'react';
import { useLoaderData } from 'react-router-dom';
import NewsSummaryCard from '../../Shared/NewsSummaryCard/NewsSummaryCard';

const Category = () => {
    return (
        <div>
        <h1>categories</h1>
        </div>
    );
};

export default Category;