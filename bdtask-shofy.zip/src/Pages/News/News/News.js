import React from 'react';
import { Link, useLoaderData } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';

const News = () => {

    return (
      <div>
    <h1>news</h1>
      </div>
    );
};

export default News;