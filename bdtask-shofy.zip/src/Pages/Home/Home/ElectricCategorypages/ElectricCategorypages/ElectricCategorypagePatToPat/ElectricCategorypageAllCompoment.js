import React from 'react';
import ProductTypeSecton from './ProductTypeElectricCategoryAndAllSite/ProductTypeSection/ProductTypeSecton';

const ElectricCategorypageAllCompoment = () => {
    return (
        <div>
            <h1>ElectricCategorypageAllCompomen</h1>
            <ProductTypeSecton></ProductTypeSecton>
            
        </div>
    );
};

export default ElectricCategorypageAllCompoment;