import React from 'react';
// import brand from "../../../../assets/TrustedBrand/Group 5414.png"

const TrustedBrand = ({ }) => {
     

        return (
        <section>
              
        </section>
        );
}
export default TrustedBrand;