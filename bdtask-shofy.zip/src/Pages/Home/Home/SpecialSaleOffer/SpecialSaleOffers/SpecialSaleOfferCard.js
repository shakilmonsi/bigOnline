import React from 'react';

const SpecialSaleOfferCard=()=> {
        return (
                <div>
                        <h1>special_offer_banner_vew_text</h1>
                        
                </div>
        );
}

export default SpecialSaleOfferCard;