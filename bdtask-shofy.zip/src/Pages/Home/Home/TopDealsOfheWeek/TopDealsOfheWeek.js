import React from 'react';
// import hardicon from "../../../../assets/hardicons/hardicon.svg"
// import startreding from "../../../../assets/iconreting/rating.svg"
// import widthstartreding from "../../../../assets/iconreting/withcolerrating.svg"
// import grayverifyde from "../../../../assets/grayverifyde/verified.svg"
// import verified from "../../../../assets/verifydeicon/image 110.png"
// import shopingcardicon from "../../../../assets/shopingcardiconbutton/shopingicon.svg"
// // import shos from  "../../../../assets/TopDealsOfTheWeek/shos.png"
// import shos from "../../../../assets/TopDealsOfTheWeek/lempe.png"
// // import shos from  "../../../../assets/TopDealsOfTheWeek/songphone.png"
// import thredot from "../../../../assets/thredoticon/thredot.svg"


const TopDealsOfheWeek = () => {
  return (
    <div>
      <h3>TopDealsOfTheWeekCard</h3>
    </div>
  
  );
}

export default TopDealsOfheWeek;