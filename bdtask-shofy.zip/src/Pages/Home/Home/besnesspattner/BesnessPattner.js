import React from 'react';


const BesnessPattner = () => {

  
  return (
  
      <div className="top-players" style={{}}>
   
      </div>

  );
}
export default BesnessPattner;