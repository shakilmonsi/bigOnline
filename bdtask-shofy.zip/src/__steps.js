/* 
BASIC PROJECT SETUP
1. create firebase app
2. get firebase configuration inside firebase.config.js
3. make sure to export app from firebase config
3. create a react app
4. install firebase and react router dom
5. install bootstrap and react-bootstrap
6. make sure to import bootstrap css in the index.js file
7. 
8. 
*/

/* 
ROUTER SETUP
1. 
*/