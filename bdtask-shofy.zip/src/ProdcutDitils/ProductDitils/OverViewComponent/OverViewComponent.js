import React from 'react';
import "./OverViewComponent.css"
const OverViewComponent = () => {
    return (
        <section className='over_view_Component_body_setup mx-auto mt-4' style={{backgroundColor:"#F5F7FB"}}>
            ,
            <div style={{ padding: 50 }}>
                <div>
                    <p className='ditils_text_style_setup'>The LG C2 42 (106cm) 4K Smart OLED evo TV is the best all-around OLED TV we've tested. Although all OLEDs deliver similar fantastic picture quality, this one stands out for its value because it has many gaming-oriented features that are great for gamers. The LG C2 42 (106cm) 4K Smart OLED evo TV is the best all-around OLED TV we've tested. Although all OLEDs deliver similar fantastic picture quality, this one stands out for its value because it has many gaming-oriented features that are great for gamers. The LG C2 42 (106cm) 4K Smart OLED evo TV is the best all-around OLED TV we've tested. Although all OLEDs deliver similar fantastic picture quality, this one stands out for its value because it has many gaming-oriented features that are great for gamers. The LG C2 42 (106cm) 4K Smart OLED evo TV is the best all-around OLED TV we've tested. Although all OLEDs deliver similar fantastic picture quality, this one stands out for its value because it has many gaming-oriented features that are great for gamers.</p>

                </div>



                <div className='grit_setup_and_list_body'>
               


                        <ul className=''>
                            <li> Size : 43''</li>
                            <li>Ram 2 GB , ROM 16 GB
                            </li>
                            <li>Brand: Sony Plus
                            </li>
                            <li>Technology: Smart /wifi / Android FULL HD led tv
                            </li>
                            <li>Aspect Ratio: 16.9 Format
                            </li>
                            <li>Display Color: 16.7 M
                            </li>
                            <li>OS : Android version 9.0 Built-In fixt
                            </li>
                            <li>Computer Monitor
                            </li>
                            <li>Wall Mount
                            </li>
                            <li>Sound system 2 Speaker Build in.
                            </li>
                            <li>Resolution 1920 x 1080 HD.4k supported
                            </li>
                            <li>HDMI Port-1

                            </li>
                        </ul>


            




                        <ul>
                            <li>                    Size : 43''
                            </li>
                            <li>Brand: Sony Plus
                            </li>
                            <li>Technology: Smart /wifi / Android FULL HD led tv
                            </li>
                            <li>Ram 2 GB , ROM 16 GB
                            </li>
                            <li>Aspect Ratio: 16.9 Format
                            </li>
                            <li>Display Color: 16.7 M

                            </li>
                            <li>OS : Android version 9.0 Built-In fixt

                            </li>
                            <li>Computer Monitor

                            </li>
                            <li>Wall Mount
                            </li>

                            <li>Sound system 2 Speaker Build in.
                            </li>
                            <li>Resolution 1920 x 1080 HD.4k supported

                            </li>
                            <li>HDMI Port-1

                            </li>
                        </ul>


                
                   
                        <ul>
                            <li>                    Size : 43''
                            </li>
                            <li>Brand: Sony Plus
                            </li>
                            <li>Technology: Smart /wifi / Android FULL HD led tv
                            </li>
                            <li>Ram 2 GB , ROM 16 GB
                            </li>
                            <li>Aspect Ratio: 16.9 Format
                            </li>
                            <li>Display Color: 16.7 M

                            </li>
                            <li>OS : Android version 9.0 Built-In fixt

                            </li>
                            <li>Computer Monitor

                            </li>
                            <li>Wall Mount
                            </li>

                            <li>Sound system 2 Speaker Build in.
                            </li>
                            <li>Resolution 1920 x 1080 HD.4k supported

                            </li>
                            <li>HDMI Port-1

                            </li>
                        </ul>

             
                </div>
            </div>
        </section>

    );
};

export default OverViewComponent;