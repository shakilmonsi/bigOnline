// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDc5QbkCPSAPK7cQbAQuDcavxFLUMIbu8I",
  authDomain: "bdtaskmsyproject.firebaseapp.com",
  projectId: "bdtaskmsyproject",
  storageBucket: "bdtaskmsyproject.appspot.com",
  messagingSenderId: "299665703937",
  appId: "1:299665703937:web:050c1f6cb4d761f87dac00"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;